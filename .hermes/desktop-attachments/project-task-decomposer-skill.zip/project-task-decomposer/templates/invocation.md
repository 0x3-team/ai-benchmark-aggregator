# Invocation template

```text
/project-task-decomposer

Input documents:
- @docs/product-handoff.md
- @docs/nonfunctional-requirements.md

Repository: current workspace
Mode: PRD_PLUS_REPO
Target leaf range: 1,500-3,000
Maximum leaf tasks: 5,000
Output project slug: example-product
Plan version: 1.0.0

Important constraints:
- Preserve the existing architecture unless a decision task justifies a change.
- Treat production deployment as approval-gated.
- Include security, accessibility, observability, migration, rollback, and test work.
- Produce the complete machine-readable corpus and human summary.
```

For a PRD-only run:

```text
/project-task-decomposer Analyze @product-requirements.md in PRD_ONLY mode. Produce a 1,000-2,500 leaf task corpus, mark architectural assumptions as provisional, and create repository-binding tasks for implementation-time resolution.
```
