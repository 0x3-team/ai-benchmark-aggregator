# Project Task Decomposer skill

A Grok Build skill that converts a PRD, product handoff, specification, or repository plan into a versioned task corpus for a later Software Orchestrator.

## Install

Project-local:

```bash
mkdir -p .grok/skills
cp -R project-task-decomposer .grok/skills/project-task-decomposer
```

User-level:

```bash
mkdir -p ~/.grok/skills
cp -R project-task-decomposer ~/.grok/skills/project-task-decomposer
```

Verify discovery:

```bash
grok inspect
```

Then invoke:

```text
/project-task-decomposer Analyze @docs/product-handoff.md and produce an implementation-ready task corpus.
```

See `templates/invocation.md` for a fuller invocation.

## Design notes

- JSONL shards are canonical because a single Markdown document does not scale safely to thousands of complete task records.
- Markdown indexes are generated for humans.
- The skill produces routing metadata but does not assign models.
- The task count is never padded with meaningless microtasks.
- `scripts/validate_task_corpus.py` provides dependency-free structural and DAG checks. Use a Draft 2020-12 JSON Schema validator for full schema enforcement.
