#!/usr/bin/env python3
"""Dependency-free structural validator for a generated task corpus.

This script intentionally checks core invariants without requiring jsonschema.
Use a Draft 2020-12 JSON Schema validator in CI for full schema validation.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Iterable

REQUIRED_TASK_FIELDS = {
    "task_id", "title", "objective", "level", "dispatchable", "category",
    "requirement_ids", "source_refs", "status", "priority", "risk", "size",
    "expected_outputs", "hard_dependencies", "acceptance_criteria",
    "verification_plan", "capability_tags", "suggested_agent_role",
    "parallelization",
}


def read_jsonl(path: Path) -> Iterable[tuple[int, dict[str, Any]]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, raw in enumerate(handle, start=1):
            if not raw.strip():
                continue
            try:
                value = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}: expected an object")
            yield line_number, value


def load_tasks(root: Path) -> tuple[dict[str, dict[str, Any]], list[str]]:
    errors: list[str] = []
    tasks: dict[str, dict[str, Any]] = {}
    task_dir = root / "tasks"
    shards = sorted(task_dir.glob("tasks-*.jsonl"))
    if not shards:
        return {}, [f"No task shards found under {task_dir}"]

    for shard in shards:
        try:
            records = list(read_jsonl(shard))
        except ValueError as exc:
            errors.append(str(exc))
            continue
        for line_number, task in records:
            missing = REQUIRED_TASK_FIELDS - task.keys()
            if missing:
                errors.append(f"{shard}:{line_number}: missing fields {sorted(missing)}")
            task_id = task.get("task_id")
            if not isinstance(task_id, str) or not task_id:
                errors.append(f"{shard}:{line_number}: invalid task_id")
                continue
            if task_id in tasks:
                errors.append(f"Duplicate task_id {task_id}")
            tasks[task_id] = task
            if task.get("dispatchable"):
                if task.get("level") != "LEAF":
                    errors.append(f"{task_id}: dispatchable task must have level LEAF")
                if task.get("size") not in {"XS", "S", "M"}:
                    errors.append(f"{task_id}: dispatchable leaf has invalid size {task.get('size')}")
                criteria = task.get("acceptance_criteria") or []
                if not criteria:
                    errors.append(f"{task_id}: dispatchable leaf has no acceptance criteria")
                if not task.get("verification_plan"):
                    errors.append(f"{task_id}: dispatchable leaf has no verification plan")
    return tasks, errors


def validate_dependencies(tasks: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    adjacency: dict[str, list[str]] = defaultdict(list)
    indegree = {task_id: 0 for task_id in tasks}

    for task_id, task in tasks.items():
        for dependency in task.get("hard_dependencies", []):
            if dependency == task_id:
                errors.append(f"{task_id}: self-dependency")
                continue
            if dependency not in tasks:
                errors.append(f"{task_id}: missing dependency {dependency}")
                continue
            adjacency[dependency].append(task_id)
            indegree[task_id] += 1

    queue = deque(task_id for task_id, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        current = queue.popleft()
        visited += 1
        for downstream in adjacency[current]:
            indegree[downstream] -= 1
            if indegree[downstream] == 0:
                queue.append(downstream)

    if visited != len(tasks):
        cyclic = sorted(task_id for task_id, degree in indegree.items() if degree > 0)
        errors.append(f"Hard dependency graph contains a cycle involving: {cyclic[:50]}")
    return errors


def validate_traceability(tasks: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    for task_id, task in tasks.items():
        if not task.get("requirement_ids"):
            errors.append(f"{task_id}: no requirement_ids")
        if not task.get("source_refs"):
            errors.append(f"{task_id}: no source_refs")
        if task.get("dispatchable") and not task.get("expected_outputs"):
            errors.append(f"{task_id}: no expected_outputs")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus_root", type=Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args()

    root = args.corpus_root.resolve()
    tasks, errors = load_tasks(root)
    errors.extend(validate_dependencies(tasks))
    errors.extend(validate_traceability(tasks))

    result = {
        "status": "PASS" if not errors else "FAIL",
        "task_count": len(tasks),
        "error_count": len(errors),
        "errors": errors,
    }
    if args.as_json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Status: {result['status']}")
        print(f"Tasks: {len(tasks)}")
        for error in errors:
            print(f"ERROR: {error}")
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
